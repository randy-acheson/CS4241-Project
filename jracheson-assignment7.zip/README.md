#CS4241 Webware: Assignment 7
>https://jracheson-assignment7.herokuapp.com/

>J Randy Acheson

Theming Choices
------

 >My website has an index page that concisely explains the purpose of the website and shows the user how to use it. The puzzle pages are clearly delineated between header and the main portion of the page. This makes it easy for a user to first figure out what to do, and then to do it. The instructions are two simple sentences at the head of the document, and there's an intuitive pause/play button that indicates whether or not the music is currently playing. The squares are spread across the screen to create a challenge for the user.


Technical Achievements
-----
>- The code to generate the puzzle table is now done using templates.
- Each different puzzle is generated using the same code, which is abstracted away to allow for multiple puzzles to be generated.
- Puzzles now scale to the size of the window.